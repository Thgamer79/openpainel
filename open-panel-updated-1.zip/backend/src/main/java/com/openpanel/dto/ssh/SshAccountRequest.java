package com.openpanel.dto.ssh;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record SshAccountRequest(
        @NotNull Long serverId,
        @NotNull Long ownerId,
        String username,
        @NotNull LocalDate expirationDate,
        @Min(1) Integer connectionLimit,
        @Min(1) Integer deviceLimit
) {
}

import { useEffect, useState } from 'react'
import { Plus, RefreshCw, Lock, Trash2 } from 'lucide-react'
import { api } from '../services/api'
import { SshAccount } from '../types/ssh'

const statusColors: Record<string, string> = {
  ATIVA: 'bg-green-500/15 text-green-400',
  SUSPENSA: 'bg-yellow-500/15 text-yellow-400',
  EXPIRADA: 'bg-red-500/15 text-red-400',
  EXCLUIDA: 'bg-white/10 text-white/40',
}

export default function SshAccounts() {
  const [accounts, setAccounts] = useState<SshAccount[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Nesta versão inicial listamos por owner fixo para demonstração;
  // trocar por seleção real de cliente/contexto de sessão.
  const ownerId = 1

  async function loadAccounts() {
    setLoading(true)
    setError('')
    try {
      const { data } = await api.get<SshAccount[]>(`/ssh-accounts/owner/${ownerId}`)
      setAccounts(data)
    } catch {
      setError('Não foi possível carregar as contas. Verifique se o backend está no ar.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAccounts()
  }, [])

  async function handleRenew(id: number) {
    await api.patch(`/ssh-accounts/${id}/renew?days=30`)
    loadAccounts()
  }

  async function handleSuspend(id: number) {
    await api.patch(`/ssh-accounts/${id}/suspend`)
    loadAccounts()
  }

  async function handleDelete(id: number) {
    if (!confirm('Excluir esta conta permanentemente?')) return
    await api.delete(`/ssh-accounts/${id}`)
    loadAccounts()
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">Contas SSH</h2>
          <p className="text-white/40 text-sm">Gerencie as contas SSH do sistema</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus size={16} /> Nova conta
        </button>
      </div>

      <div className="card overflow-x-auto">
        {loading ? (
          <p className="text-white/40 text-sm">Carregando...</p>
        ) : error ? (
          <p className="text-red-400 text-sm">{error}</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-white/40 border-b border-white/5">
                <th className="pb-3 font-normal">Usuário</th>
                <th className="pb-3 font-normal">Servidor</th>
                <th className="pb-3 font-normal">Expira em</th>
                <th className="pb-3 font-normal">Limites</th>
                <th className="pb-3 font-normal">Status</th>
                <th className="pb-3 font-normal text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {accounts.map((acc) => (
                <tr key={acc.id} className="border-b border-white/5 last:border-0">
                  <td className="py-3 font-medium">{acc.username}</td>
                  <td className="py-3 text-white/60">{acc.serverName}</td>
                  <td className="py-3 text-white/60">{acc.expirationDate}</td>
                  <td className="py-3 text-white/60">
                    {acc.connectionLimit} conexões / {acc.deviceLimit} dispositivos
                  </td>
                  <td className="py-3">
                    <span className={`px-2 py-1 rounded-lg text-xs ${statusColors[acc.status]}`}>
                      {acc.status}
                    </span>
                  </td>
                  <td className="py-3">
                    <div className="flex justify-end gap-2">
                      <button onClick={() => handleRenew(acc.id)} title="Renovar" className="p-2 rounded-lg hover:bg-white/5 text-white/50 hover:text-primary-light">
                        <RefreshCw size={16} />
                      </button>
                      <button onClick={() => handleSuspend(acc.id)} title="Suspender" className="p-2 rounded-lg hover:bg-white/5 text-white/50 hover:text-yellow-400">
                        <Lock size={16} />
                      </button>
                      <button onClick={() => handleDelete(acc.id)} title="Excluir" className="p-2 rounded-lg hover:bg-white/5 text-white/50 hover:text-red-400">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {accounts.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-white/30">Nenhuma conta encontrada</td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

# Open Panel

Painel comercial para gerenciamento de SSH, V2Ray, WireGuard e OpenVPN.

## Stack

- **Backend:** Java 21, Spring Boot 3, Spring Security (JWT), PostgreSQL, Redis, RabbitMQ
- **Frontend:** React + TypeScript + TailwindCSS
- **Infra:** Docker Compose, Nginx

## Instalação (produção)

1. Copie o arquivo de variáveis de ambiente e ajuste os valores:
   ```bash
   cp .env.example .env
   ```
2. Suba todos os serviços:
   ```bash
   docker compose up -d
   ```
3. Acesse:
   - Painel: `http://SEU_IP`
   - API: `http://SEU_IP:8080/api`
   - Swagger: `http://SEU_IP:8080/docs`

## Estrutura

```
open-panel/
├── backend/     # Spring Boot (Java 21)
├── frontend/    # React + Tailwind
└── docker-compose.yml
```

## Status atual

Implementado nesta fase:
- Autenticação JWT + RBAC (ADMIN, REVENDEDOR, SUB_REVENDEDOR, CLIENTE)
- CRUD completo de contas SSH com criação/renovação/suspensão/exclusão reais via SSH remoto (JSch)
- Expiração automática diária (scheduler)
- Criptografia AES das credenciais de servidores
- Dashboard com métricas e gráficos (contas SSH e receita ainda com dados de exemplo; servidores online/offline já usam dados reais)
- Módulo Servidores completo: CRUD (`/api/servers`), credencial SSH criptografada em repouso, teste de conectividade e coleta real de CPU/RAM/disco/latência via SSH (`POST /api/servers/{id}/refresh`), tela dedicada no frontend (cadastro, edição, exclusão, atualização de métricas)
- Estrutura de menu completa (demais módulos como placeholder "em desenvolvimento")

Próximas etapas sugeridas: módulo V2Ray (depende dos servidores já implementados), WireGuard, OpenVPN, Combo, pagamentos (Mercado Pago/PIX), loja pública, Cloudflare, 2FA, i18n.

## Criação do primeiro usuário admin

Ainda não há endpoint de seed. Insira manualmente após o primeiro `docker compose up -d`:

```sql
INSERT INTO roles (name) VALUES ('ADMIN'), ('REVENDEDOR'), ('SUB_REVENDEDOR'), ('CLIENTE');

INSERT INTO users (username, email, password, full_name, enabled, two_factor_enabled, credits, role_id, created_at, updated_at)
VALUES ('admin', 'admin@openpanel.local', '$SENHA_BCRYPT', 'Administrador', true, false, 0, 1, now(), now());
```

Gere o hash bcrypt da senha (ex: com um script Java/Node usando BCrypt, custo 12) antes de inserir.

import { LucideIcon } from 'lucide-react'

interface StatCardProps {
  title: string
  value: string | number
  icon: LucideIcon
  color?: string
  suffix?: string
}

export default function StatCard({ title, value, icon: Icon, color = 'text-primary-light', suffix }: StatCardProps) {
  return (
    <div className="card flex items-center justify-between">
      <div>
        <p className="text-white/50 text-xs mb-1">{title}</p>
        <p className="text-2xl font-bold">
          {value}
          {suffix && <span className="text-sm text-white/40 ml-1">{suffix}</span>}
        </p>
      </div>
      <div className={`p-3 rounded-xl bg-white/5 ${color}`}>
        <Icon size={22} />
      </div>
    </div>
  )
}

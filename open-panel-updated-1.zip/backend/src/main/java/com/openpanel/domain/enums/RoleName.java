package com.openpanel.domain.enums;

/**
 * Papéis do sistema (RBAC).
 * Hierarquia: ADMIN > REVENDEDOR > SUB_REVENDEDOR > CLIENTE
 */
public enum RoleName {
    ADMIN,
    REVENDEDOR,
    SUB_REVENDEDOR,
    CLIENTE
}

package com.openpanel.dto.server;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * sshCredential é obrigatório na criação. Na atualização, deixar em branco/nulo
 * mantém a credencial já armazenada (não é reenviada em texto puro pelo frontend).
 */
public record ServerRequest(
        @NotBlank String name,
        @NotBlank String host,
        @NotNull @Min(1) Integer sshPort,
        @NotBlank String sshUser,
        String sshCredential
) {
}

package com.openpanel.domain.enums;

public enum AccountStatus {
    ATIVA,
    SUSPENSA,
    EXPIRADA,
    EXCLUIDA
}

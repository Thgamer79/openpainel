package com.openpanel.service;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.openpanel.domain.entity.Server;
import com.openpanel.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Executa comandos shell em servidores remotos via SSH (JSch).
 * Usado para criar/renovar/suspender/excluir contas de sistema,
 * bem como para coletar métricas (CPU/RAM/disco) do servidor.
 */
@Service
public class RemoteSshExecutor {

    private static final Logger log = LoggerFactory.getLogger(RemoteSshExecutor.class);

    /**
     * Executa um comando remoto e retorna a saída padrão.
     * A credencial já deve estar descriptografada neste ponto.
     */
    public String execute(Server server, String plainCredential, String command) {
        Session session = null;
        ChannelExec channel = null;
        try {
            JSch jsch = new JSch();
            session = jsch.getSession(server.getSshUser(), server.getHost(), server.getSshPort());
            session.setPassword(plainCredential);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect(10_000);

            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(command);
            channel.setErrStream(System.err);

            InputStream in = channel.getInputStream();
            channel.connect();

            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }

            return output.toString().trim();
        } catch (Exception ex) {
            log.error("Falha ao executar comando SSH no servidor {}: {}", server.getHost(), ex.getMessage());
            throw new BusinessException("Falha na comunicação com o servidor remoto: " + server.getName());
        } finally {
            if (channel != null) channel.disconnect();
            if (session != null) session.disconnect();
        }
    }

    public String createLinuxUser(Server server, String plainCredential, String username, String password, java.time.LocalDate expiration) {
        String cmd = String.format(
                "useradd -e %s -s /bin/false -M %s && echo '%s:%s' | chpasswd",
                expiration, username, username, password
        );
        return execute(server, plainCredential, cmd);
    }

    public String renewLinuxUser(Server server, String plainCredential, String username, java.time.LocalDate newExpiration) {
        String cmd = String.format("usermod -e %s %s", newExpiration, username);
        return execute(server, plainCredential, cmd);
    }

    public String lockLinuxUser(Server server, String plainCredential, String username) {
        return execute(server, plainCredential, "usermod -L " + username);
    }

    public String unlockLinuxUser(Server server, String plainCredential, String username) {
        return execute(server, plainCredential, "usermod -U " + username);
    }

    public String deleteLinuxUser(Server server, String plainCredential, String username) {
        return execute(server, plainCredential, "userdel -f " + username);
    }

    public String getCpuUsage(Server server, String plainCredential) {
        return execute(server, plainCredential,
                "top -bn1 | grep 'Cpu(s)' | awk '{print $2+$4}'");
    }

    public String getRamUsage(Server server, String plainCredential) {
        return execute(server, plainCredential,
                "free | grep Mem | awk '{print ($3/$2) * 100.0}'");
    }

    public String getDiskUsage(Server server, String plainCredential) {
        return execute(server, plainCredential,
                "df -h / | tail -1 | awk '{print $5}' | tr -d '%'");
    }

    /**
     * Testa a conectividade com o servidor e mede a latência (ms) de um comando trivial.
     * Usado para o status online/offline exibido no módulo de Servidores e no Dashboard.
     */
    public long ping(Server server, String plainCredential) {
        long start = System.currentTimeMillis();
        execute(server, plainCredential, "echo ok");
        return System.currentTimeMillis() - start;
    }
}

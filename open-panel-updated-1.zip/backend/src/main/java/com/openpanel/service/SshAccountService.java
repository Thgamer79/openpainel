package com.openpanel.service;

import com.openpanel.domain.entity.Server;
import com.openpanel.domain.entity.SshAccount;
import com.openpanel.domain.entity.User;
import com.openpanel.domain.enums.AccountStatus;
import com.openpanel.dto.ssh.SshAccountRequest;
import com.openpanel.dto.ssh.SshAccountResponse;
import com.openpanel.exception.BusinessException;
import com.openpanel.exception.ResourceNotFoundException;
import com.openpanel.repository.ServerRepository;
import com.openpanel.repository.SshAccountRepository;
import com.openpanel.repository.UserRepository;
import com.openpanel.util.PasswordGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class SshAccountService {

    private final SshAccountRepository sshAccountRepository;
    private final ServerRepository serverRepository;
    private final UserRepository userRepository;
    private final RemoteSshExecutor remoteSshExecutor;
    private final CredentialCipherService cipherService;

    public SshAccountService(SshAccountRepository sshAccountRepository,
                              ServerRepository serverRepository,
                              UserRepository userRepository,
                              RemoteSshExecutor remoteSshExecutor,
                              CredentialCipherService cipherService) {
        this.sshAccountRepository = sshAccountRepository;
        this.serverRepository = serverRepository;
        this.userRepository = userRepository;
        this.remoteSshExecutor = remoteSshExecutor;
        this.cipherService = cipherService;
    }

    @Transactional
    public SshAccountResponse create(SshAccountRequest request) {
        Server server = serverRepository.findById(request.serverId())
                .orElseThrow(() -> new ResourceNotFoundException("Servidor não encontrado"));

        User owner = userRepository.findById(request.ownerId())
                .orElseThrow(() -> new ResourceNotFoundException("Cliente não encontrado"));

        String username = (request.username() == null || request.username().isBlank())
                ? PasswordGenerator.generateUsername("op")
                : request.username();

        if (sshAccountRepository.existsByUsername(username)) {
            throw new BusinessException("Nome de usuário já existe: " + username);
        }

        String password = PasswordGenerator.generate(10);
        String plainCredential = cipherService.decrypt(server.getSshCredentialEncrypted());

        remoteSshExecutor.createLinuxUser(server, plainCredential, username, password, request.expirationDate());

        SshAccount account = new SshAccount();
        account.setServer(server);
        account.setOwner(owner);
        account.setUsername(username);
        account.setPassword(password);
        account.setExpirationDate(request.expirationDate());
        account.setConnectionLimit(request.connectionLimit() != null ? request.connectionLimit() : 1);
        account.setDeviceLimit(request.deviceLimit() != null ? request.deviceLimit() : 1);
        account.setStatus(AccountStatus.ATIVA);

        return toResponse(sshAccountRepository.save(account));
    }

    @Transactional
    public SshAccountResponse renew(Long accountId, int days) {
        SshAccount account = getOrThrow(accountId);
        Server server = account.getServer();
        String plainCredential = cipherService.decrypt(server.getSshCredentialEncrypted());

        LocalDate newExpiration = account.getExpirationDate().isAfter(LocalDate.now())
                ? account.getExpirationDate().plusDays(days)
                : LocalDate.now().plusDays(days);

        remoteSshExecutor.renewLinuxUser(server, plainCredential, account.getUsername(), newExpiration);

        account.setExpirationDate(newExpiration);
        account.setStatus(AccountStatus.ATIVA);
        return toResponse(sshAccountRepository.save(account));
    }

    @Transactional
    public SshAccountResponse suspend(Long accountId) {
        SshAccount account = getOrThrow(accountId);
        Server server = account.getServer();
        String plainCredential = cipherService.decrypt(server.getSshCredentialEncrypted());

        remoteSshExecutor.lockLinuxUser(server, plainCredential, account.getUsername());
        account.setStatus(AccountStatus.SUSPENSA);
        return toResponse(sshAccountRepository.save(account));
    }

    @Transactional
    public void delete(Long accountId) {
        SshAccount account = getOrThrow(accountId);
        Server server = account.getServer();
        String plainCredential = cipherService.decrypt(server.getSshCredentialEncrypted());

        remoteSshExecutor.deleteLinuxUser(server, plainCredential, account.getUsername());
        account.setStatus(AccountStatus.EXCLUIDA);
        sshAccountRepository.save(account);
    }

    public List<SshAccountResponse> listByOwner(Long ownerId) {
        return sshAccountRepository.findByOwnerId(ownerId).stream()
                .map(this::toResponse)
                .toList();
    }

    private SshAccount getOrThrow(Long id) {
        return sshAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Conta SSH não encontrada"));
    }

    private SshAccountResponse toResponse(SshAccount a) {
        return new SshAccountResponse(
                a.getId(),
                a.getServer().getId(),
                a.getServer().getName(),
                a.getUsername(),
                a.getPassword(),
                a.getExpirationDate(),
                a.getConnectionLimit(),
                a.getDeviceLimit(),
                a.getStatus()
        );
    }
}

package com.openpanel.dto.auth;

public record LoginResponse(
        String accessToken,
        String refreshToken,
        String username,
        String role
) {
}

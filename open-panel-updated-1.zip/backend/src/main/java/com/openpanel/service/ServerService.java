package com.openpanel.service;

import com.openpanel.domain.entity.Server;
import com.openpanel.dto.server.ServerRequest;
import com.openpanel.dto.server.ServerResponse;
import com.openpanel.exception.BusinessException;
import com.openpanel.exception.ResourceNotFoundException;
import com.openpanel.repository.ServerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ServerService {

    private static final Logger log = LoggerFactory.getLogger(ServerService.class);

    private final ServerRepository serverRepository;
    private final RemoteSshExecutor remoteSshExecutor;
    private final CredentialCipherService cipherService;

    public ServerService(ServerRepository serverRepository,
                          RemoteSshExecutor remoteSshExecutor,
                          CredentialCipherService cipherService) {
        this.serverRepository = serverRepository;
        this.remoteSshExecutor = remoteSshExecutor;
        this.cipherService = cipherService;
    }

    @Transactional
    public ServerResponse create(ServerRequest request) {
        if (request.sshCredential() == null || request.sshCredential().isBlank()) {
            throw new BusinessException("Informe a senha ou chave SSH do servidor");
        }

        Server server = new Server();
        server.setName(request.name());
        server.setHost(request.host());
        server.setSshPort(request.sshPort());
        server.setSshUser(request.sshUser());
        server.setSshCredentialEncrypted(cipherService.encrypt(request.sshCredential()));

        return toResponse(serverRepository.save(server));
    }

    @Transactional
    public ServerResponse update(Long id, ServerRequest request) {
        Server server = getOrThrow(id);
        server.setName(request.name());
        server.setHost(request.host());
        server.setSshPort(request.sshPort());
        server.setSshUser(request.sshUser());

        if (request.sshCredential() != null && !request.sshCredential().isBlank()) {
            server.setSshCredentialEncrypted(cipherService.encrypt(request.sshCredential()));
        }

        return toResponse(serverRepository.save(server));
    }

    @Transactional
    public void delete(Long id) {
        Server server = getOrThrow(id);
        serverRepository.delete(server);
    }

    public List<ServerResponse> list() {
        return serverRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    public ServerResponse getById(Long id) {
        return toResponse(getOrThrow(id));
    }

    /**
     * Testa a conectividade e coleta CPU/RAM/disco/latência reais do servidor via SSH.
     * Em caso de falha de comunicação, marca o servidor como offline em vez de propagar o erro,
     * já que esta é uma checagem de status, não uma operação crítica de negócio.
     */
    @Transactional
    public ServerResponse refreshMetrics(Long id) {
        Server server = getOrThrow(id);
        String plainCredential = cipherService.decrypt(server.getSshCredentialEncrypted());

        try {
            long pingMs = remoteSshExecutor.ping(server, plainCredential);
            Double cpu = parseUsage(remoteSshExecutor.getCpuUsage(server, plainCredential));
            Double ram = parseUsage(remoteSshExecutor.getRamUsage(server, plainCredential));
            Double disk = parseUsage(remoteSshExecutor.getDiskUsage(server, plainCredential));

            server.setOnline(true);
            server.setLastPingMs(pingMs);
            server.setCpuUsage(cpu);
            server.setRamUsage(ram);
            server.setDiskUsage(disk);
        } catch (BusinessException ex) {
            log.warn("Servidor {} está offline: {}", server.getName(), ex.getMessage());
            server.setOnline(false);
        }

        return toResponse(serverRepository.save(server));
    }

    private Double parseUsage(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Double.parseDouble(raw.trim().replace(",", "."));
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Server getOrThrow(Long id) {
        return serverRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Servidor não encontrado"));
    }

    private ServerResponse toResponse(Server s) {
        return new ServerResponse(
                s.getId(),
                s.getName(),
                s.getHost(),
                s.getSshPort(),
                s.getSshUser(),
                s.isOnline(),
                s.getCpuUsage(),
                s.getRamUsage(),
                s.getDiskUsage(),
                s.getLastPingMs()
        );
    }
}

package com.openpanel.domain.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "servers")
@Getter
@Setter
public class Server extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 255)
    private String host;

    @Column(nullable = false)
    private Integer sshPort = 22;

    @Column(nullable = false, length = 100)
    private String sshUser;

    /** Senha ou chave privada, sempre armazenada criptografada (AES) na camada de serviço */
    @Column(nullable = false, columnDefinition = "TEXT")
    private String sshCredentialEncrypted;

    @Column(nullable = false)
    private boolean online = false;

    private Double cpuUsage;
    private Double ramUsage;
    private Double diskUsage;
    private Long lastPingMs;
}

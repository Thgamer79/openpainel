export interface OpServer {
  id: number
  name: string
  host: string
  sshPort: number
  sshUser: string
  online: boolean
  cpuUsage: number | null
  ramUsage: number | null
  diskUsage: number | null
  lastPingMs: number | null
}

export interface ServerRequest {
  name: string
  host: string
  sshPort: number
  sshUser: string
  sshCredential?: string
}

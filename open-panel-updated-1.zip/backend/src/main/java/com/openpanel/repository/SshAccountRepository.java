package com.openpanel.repository;

import com.openpanel.domain.entity.SshAccount;
import com.openpanel.domain.enums.AccountStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface SshAccountRepository extends JpaRepository<SshAccount, Long> {
    List<SshAccount> findByOwnerId(Long ownerId);
    List<SshAccount> findByStatusAndExpirationDateBefore(AccountStatus status, LocalDate date);
    boolean existsByUsername(String username);
}

package com.openpanel.service;

import com.openpanel.domain.entity.SshAccount;
import com.openpanel.domain.enums.AccountStatus;
import com.openpanel.repository.SshAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

/**
 * Verifica diariamente contas SSH expiradas e as suspende automaticamente no
 * banco e no servidor remoto (CheckUser / expiração automática do escopo).
 */
@Component
public class AccountExpirationScheduler {

    private static final Logger log = LoggerFactory.getLogger(AccountExpirationScheduler.class);

    private final SshAccountRepository sshAccountRepository;
    private final RemoteSshExecutor remoteSshExecutor;
    private final CredentialCipherService cipherService;

    public AccountExpirationScheduler(SshAccountRepository sshAccountRepository,
                                       RemoteSshExecutor remoteSshExecutor,
                                       CredentialCipherService cipherService) {
        this.sshAccountRepository = sshAccountRepository;
        this.remoteSshExecutor = remoteSshExecutor;
        this.cipherService = cipherService;
    }

    @Scheduled(cron = "0 5 0 * * *")
    public void expireOverdueAccounts() {
        List<SshAccount> expired = sshAccountRepository
                .findByStatusAndExpirationDateBefore(AccountStatus.ATIVA, LocalDate.now());

        for (SshAccount account : expired) {
            try {
                String plainCredential = cipherService.decrypt(account.getServer().getSshCredentialEncrypted());
                remoteSshExecutor.lockLinuxUser(account.getServer(), plainCredential, account.getUsername());
                account.setStatus(AccountStatus.EXPIRADA);
                sshAccountRepository.save(account);
            } catch (Exception ex) {
                log.error("Erro ao expirar conta {}: {}", account.getUsername(), ex.getMessage());
            }
        }
    }
}

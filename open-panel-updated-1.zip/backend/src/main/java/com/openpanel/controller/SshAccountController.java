package com.openpanel.controller;

import com.openpanel.dto.ssh.SshAccountRequest;
import com.openpanel.dto.ssh.SshAccountResponse;
import com.openpanel.service.SshAccountService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ssh-accounts")
@Tag(name = "Contas SSH")
public class SshAccountController {

    private final SshAccountService sshAccountService;

    public SshAccountController(SshAccountService sshAccountService) {
        this.sshAccountService = sshAccountService;
    }

    @PostMapping
    public ResponseEntity<SshAccountResponse> create(@Valid @RequestBody SshAccountRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(sshAccountService.create(request));
    }

    @PatchMapping("/{id}/renew")
    public ResponseEntity<SshAccountResponse> renew(@PathVariable Long id, @RequestParam(defaultValue = "30") int days) {
        return ResponseEntity.ok(sshAccountService.renew(id, days));
    }

    @PatchMapping("/{id}/suspend")
    public ResponseEntity<SshAccountResponse> suspend(@PathVariable Long id) {
        return ResponseEntity.ok(sshAccountService.suspend(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        sshAccountService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<SshAccountResponse>> listByOwner(@PathVariable Long ownerId) {
        return ResponseEntity.ok(sshAccountService.listByOwner(ownerId));
    }
}

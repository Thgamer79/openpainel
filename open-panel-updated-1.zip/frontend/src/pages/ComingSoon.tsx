interface ComingSoonProps {
  title: string
}

export default function ComingSoon({ title }: ComingSoonProps) {
  return (
    <div className="space-y-2">
      <h2 className="text-xl font-bold">{title}</h2>
      <div className="card mt-4">
        <p className="text-white/40 text-sm">
          Módulo "{title}" em desenvolvimento. Será implementado na próxima etapa do projeto.
        </p>
      </div>
    </div>
  )
}

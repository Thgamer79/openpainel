package com.openpanel.domain.enums;

public enum ProtocolType {
    SSH,
    V2RAY,
    WIREGUARD,
    OPENVPN,
    COMBO
}

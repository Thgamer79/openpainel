export type AccountStatus = 'ATIVA' | 'SUSPENSA' | 'EXPIRADA' | 'EXCLUIDA'

export interface SshAccount {
  id: number
  serverId: number
  serverName: string
  username: string
  password: string
  expirationDate: string
  connectionLimit: number
  deviceLimit: number
  status: AccountStatus
}

export interface SshAccountRequest {
  serverId: number
  ownerId: number
  username?: string
  expirationDate: string
  connectionLimit: number
  deviceLimit: number
}

import { createContext, useContext, useState, ReactNode } from 'react'
import { api } from '../services/api'

interface AuthState {
  username: string | null
  role: string | null
  isAuthenticated: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthState | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [username, setUsername] = useState<string | null>(localStorage.getItem('op_username'))
  const [role, setRole] = useState<string | null>(localStorage.getItem('op_role'))

  async function login(user: string, password: string) {
    const { data } = await api.post('/auth/login', { username: user, password })
    localStorage.setItem('op_access_token', data.accessToken)
    localStorage.setItem('op_username', data.username)
    localStorage.setItem('op_role', data.role)
    setUsername(data.username)
    setRole(data.role)
  }

  function logout() {
    localStorage.clear()
    setUsername(null)
    setRole(null)
  }

  return (
    <AuthContext.Provider value={{ username, role, isAuthenticated: !!username, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider')
  return ctx
}

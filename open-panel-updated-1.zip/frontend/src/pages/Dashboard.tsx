import { useEffect, useState } from 'react'
import { Terminal, Globe, Shield, Cable, Users, Server, Wallet, Clock } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import StatCard from '../components/StatCard'
import { api } from '../services/api'
import { OpServer } from '../types/server'

const cpuData = [
  { time: '00h', value: 22 }, { time: '04h', value: 18 }, { time: '08h', value: 35 },
  { time: '12h', value: 48 }, { time: '16h', value: 40 }, { time: '20h', value: 30 }, { time: '23h', value: 25 }
]

const revenueData = [
  { day: 'Seg', valor: 320 }, { day: 'Ter', valor: 480 }, { day: 'Qua', valor: 290 },
  { day: 'Qui', valor: 610 }, { day: 'Sex', valor: 540 }, { day: 'Sáb', valor: 720 }, { day: 'Dom', valor: 400 }
]

export default function Dashboard() {
  const [servers, setServers] = useState<OpServer[]>([])

  useEffect(() => {
    api.get<OpServer[]>('/servers')
      .then(({ data }) => setServers(data))
      .catch(() => setServers([]))
  }, [])

  const serversOnline = servers.filter((s) => s.online).length
  const serversOffline = servers.length - serversOnline

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">Dashboard</h2>
        <p className="text-white/40 text-sm">Visão geral do sistema em tempo real</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Contas SSH" value={128} icon={Terminal} />
        <StatCard title="Contas V2Ray" value={64} icon={Globe} color="text-accent-light" />
        <StatCard title="Contas WireGuard" value={40} icon={Shield} />
        <StatCard title="Contas OpenVPN" value={22} icon={Cable} color="text-accent-light" />
        <StatCard title="Usuários online" value={57} icon={Users} />
        <StatCard title="Servidores online" value={serversOnline} icon={Server} />
        <StatCard title="Servidores offline" value={serversOffline} icon={Server} color="text-red-400" />
        <StatCard title="Pagamentos pendentes" value={3} icon={Clock} color="text-yellow-400" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard title="Receita do dia" value="R$ 420" icon={Wallet} />
        <StatCard title="Receita do mês" value="R$ 8.940" icon={Wallet} color="text-accent-light" />
        <StatCard title="Receita total" value="R$ 62.310" icon={Wallet} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card">
          <h3 className="text-sm font-medium mb-4 text-white/70">Uso de CPU (24h)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={cpuData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="time" stroke="#ffffff40" fontSize={12} />
              <YAxis stroke="#ffffff40" fontSize={12} />
              <Tooltip contentStyle={{ background: '#15151f', border: '1px solid #ffffff20', borderRadius: 8 }} />
              <Line type="monotone" dataKey="value" stroke="#a78bfa" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="text-sm font-medium mb-4 text-white/70">Receita (7 dias)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="day" stroke="#ffffff40" fontSize={12} />
              <YAxis stroke="#ffffff40" fontSize={12} />
              <Tooltip contentStyle={{ background: '#15151f', border: '1px solid #ffffff20', borderRadius: 8 }} />
              <Line type="monotone" dataKey="valor" stroke="#60a5fa" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import PrivateRoute from './components/PrivateRoute'
import DashboardLayout from './components/layout/DashboardLayout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import SshAccounts from './pages/SshAccounts'
import Servidores from './pages/Servidores'
import ComingSoon from './pages/ComingSoon'

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route
            element={
              <PrivateRoute>
                <DashboardLayout />
              </PrivateRoute>
            }
          >
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/ssh" element={<SshAccounts />} />
            <Route path="/v2ray" element={<ComingSoon title="V2Ray" />} />
            <Route path="/wireguard" element={<ComingSoon title="WireGuard" />} />
            <Route path="/openvpn" element={<ComingSoon title="OpenVPN" />} />
            <Route path="/combo" element={<ComingSoon title="Combo" />} />
            <Route path="/clientes" element={<ComingSoon title="Clientes" />} />
            <Route path="/revendedores" element={<ComingSoon title="Revendedores" />} />
            <Route path="/servidores" element={<Servidores />} />
            <Route path="/pagamentos" element={<ComingSoon title="Pagamentos" />} />
            <Route path="/loja" element={<ComingSoon title="Loja" />} />
            <Route path="/relatorios" element={<ComingSoon title="Relatórios" />} />
            <Route path="/notificacoes" element={<ComingSoon title="Notificações" />} />
            <Route path="/sistema" element={<ComingSoon title="Sistema" />} />
          </Route>

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

package com.openpanel.dto.server;

public record ServerResponse(
        Long id,
        String name,
        String host,
        Integer sshPort,
        String sshUser,
        boolean online,
        Double cpuUsage,
        Double ramUsage,
        Double diskUsage,
        Long lastPingMs
) {
}

package com.openpanel.controller;

import com.openpanel.dto.server.ServerRequest;
import com.openpanel.dto.server.ServerResponse;
import com.openpanel.service.ServerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/servers")
@Tag(name = "Servidores")
public class ServerController {

    private final ServerService serverService;

    public ServerController(ServerService serverService) {
        this.serverService = serverService;
    }

    @GetMapping
    @Operation(summary = "Lista todos os servidores cadastrados")
    public ResponseEntity<List<ServerResponse>> list() {
        return ResponseEntity.ok(serverService.list());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca um servidor por ID")
    public ResponseEntity<ServerResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(serverService.getById(id));
    }

    @PostMapping
    @Operation(summary = "Cadastra um novo servidor")
    public ResponseEntity<ServerResponse> create(@Valid @RequestBody ServerRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(serverService.create(request));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza um servidor existente")
    public ResponseEntity<ServerResponse> update(@PathVariable Long id, @Valid @RequestBody ServerRequest request) {
        return ResponseEntity.ok(serverService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Remove um servidor")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        serverService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/refresh")
    @Operation(summary = "Testa conectividade e atualiza métricas reais (CPU/RAM/disco/ping) via SSH")
    public ResponseEntity<ServerResponse> refresh(@PathVariable Long id) {
        return ResponseEntity.ok(serverService.refreshMetrics(id));
    }
}

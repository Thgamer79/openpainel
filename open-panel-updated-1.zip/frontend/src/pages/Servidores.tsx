import { useEffect, useState } from 'react'
import { Plus, RefreshCw, Pencil, Trash2, X } from 'lucide-react'
import { api } from '../services/api'
import { OpServer, ServerRequest } from '../types/server'

const emptyForm: ServerRequest = {
  name: '',
  host: '',
  sshPort: 22,
  sshUser: 'root',
  sshCredential: '',
}

function UsageBar({ label, value }: { label: string; value: number | null }) {
  const pct = value ?? 0
  const color = pct >= 90 ? 'bg-red-400' : pct >= 70 ? 'bg-yellow-400' : 'bg-primary-light'
  return (
    <div className="w-28">
      <div className="flex justify-between text-[11px] text-white/40 mb-1">
        <span>{label}</span>
        <span>{value === null ? '—' : `${value.toFixed(0)}%`}</span>
      </div>
      <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${Math.min(pct, 100)}%` }} />
      </div>
    </div>
  )
}

export default function Servidores() {
  const [servers, setServers] = useState<OpServer[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [refreshingId, setRefreshingId] = useState<number | null>(null)

  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<number | null>(null)
  const [form, setForm] = useState<ServerRequest>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState('')

  async function loadServers() {
    setLoading(true)
    setError('')
    try {
      const { data } = await api.get<OpServer[]>('/servers')
      setServers(data)
    } catch {
      setError('Não foi possível carregar os servidores. Verifique se o backend está no ar.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadServers()
  }, [])

  function openCreateForm() {
    setEditingId(null)
    setForm(emptyForm)
    setFormError('')
    setShowForm(true)
  }

  function openEditForm(server: OpServer) {
    setEditingId(server.id)
    setForm({
      name: server.name,
      host: server.host,
      sshPort: server.sshPort,
      sshUser: server.sshUser,
      sshCredential: '',
    })
    setFormError('')
    setShowForm(true)
  }

  async function handleSubmit() {
    setFormError('')
    if (!form.name || !form.host || !form.sshUser) {
      setFormError('Preencha nome, host e usuário SSH.')
      return
    }
    if (!editingId && !form.sshCredential) {
      setFormError('Informe a senha ou chave SSH para um novo servidor.')
      return
    }

    setSaving(true)
    try {
      if (editingId) {
        await api.put(`/servers/${editingId}`, form)
      } else {
        await api.post('/servers', form)
      }
      setShowForm(false)
      loadServers()
    } catch {
      setFormError('Não foi possível salvar o servidor. Verifique os dados informados.')
    } finally {
      setSaving(false)
    }
  }

  async function handleRefresh(id: number) {
    setRefreshingId(id)
    try {
      await api.post(`/servers/${id}/refresh`)
      loadServers()
    } finally {
      setRefreshingId(null)
    }
  }

  async function handleDelete(id: number) {
    if (!confirm('Remover este servidor permanentemente?')) return
    await api.delete(`/servers/${id}`)
    loadServers()
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">Servidores</h2>
          <p className="text-white/40 text-sm">Cadastre e monitore os servidores usados para provisionar contas</p>
        </div>
        <button onClick={openCreateForm} className="btn-primary flex items-center gap-2">
          <Plus size={16} /> Novo servidor
        </button>
      </div>

      {showForm && (
        <div className="card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-white/70">
              {editingId ? 'Editar servidor' : 'Novo servidor'}
            </h3>
            <button onClick={() => setShowForm(false)} className="text-white/40 hover:text-white">
              <X size={18} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-white/40 block mb-1">Nome</label>
              <input
                className="w-full bg-surfaceLight border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Ex: SP-01"
              />
            </div>
            <div>
              <label className="text-xs text-white/40 block mb-1">Host / IP</label>
              <input
                className="w-full bg-surfaceLight border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary"
                value={form.host}
                onChange={(e) => setForm({ ...form, host: e.target.value })}
                placeholder="Ex: 191.0.2.10"
              />
            </div>
            <div>
              <label className="text-xs text-white/40 block mb-1">Porta SSH</label>
              <input
                type="number"
                className="w-full bg-surfaceLight border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary"
                value={form.sshPort}
                onChange={(e) => setForm({ ...form, sshPort: Number(e.target.value) })}
              />
            </div>
            <div>
              <label className="text-xs text-white/40 block mb-1">Usuário SSH</label>
              <input
                className="w-full bg-surfaceLight border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary"
                value={form.sshUser}
                onChange={(e) => setForm({ ...form, sshUser: e.target.value })}
              />
            </div>
            <div className="md:col-span-2">
              <label className="text-xs text-white/40 block mb-1">
                Senha SSH {editingId && <span className="text-white/30">(deixe em branco para manter a atual)</span>}
              </label>
              <input
                type="password"
                className="w-full bg-surfaceLight border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-primary"
                value={form.sshCredential}
                onChange={(e) => setForm({ ...form, sshCredential: e.target.value })}
                placeholder={editingId ? '••••••••' : ''}
              />
            </div>
          </div>

          {formError && <p className="text-red-400 text-sm">{formError}</p>}

          <div className="flex justify-end gap-2">
            <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-xl text-sm text-white/60 hover:bg-white/5">
              Cancelar
            </button>
            <button onClick={handleSubmit} disabled={saving} className="btn-primary disabled:opacity-50">
              {saving ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </div>
      )}

      <div className="card overflow-x-auto">
        {loading ? (
          <p className="text-white/40 text-sm">Carregando...</p>
        ) : error ? (
          <p className="text-red-400 text-sm">{error}</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-white/40 border-b border-white/5">
                <th className="pb-3 font-normal">Nome</th>
                <th className="pb-3 font-normal">Host</th>
                <th className="pb-3 font-normal">Status</th>
                <th className="pb-3 font-normal">Métricas</th>
                <th className="pb-3 font-normal">Latência</th>
                <th className="pb-3 font-normal text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {servers.map((s) => (
                <tr key={s.id} className="border-b border-white/5 last:border-0">
                  <td className="py-3 font-medium">{s.name}</td>
                  <td className="py-3 text-white/60">{s.host}:{s.sshPort}</td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-1 rounded-lg text-xs ${
                        s.online ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400'
                      }`}
                    >
                      {s.online ? 'Online' : 'Offline'}
                    </span>
                  </td>
                  <td className="py-3">
                    <div className="flex gap-4">
                      <UsageBar label="CPU" value={s.cpuUsage} />
                      <UsageBar label="RAM" value={s.ramUsage} />
                      <UsageBar label="Disco" value={s.diskUsage} />
                    </div>
                  </td>
                  <td className="py-3 text-white/60">
                    {s.lastPingMs === null ? '—' : `${s.lastPingMs} ms`}
                  </td>
                  <td className="py-3">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => handleRefresh(s.id)}
                        title="Testar conexão / atualizar métricas"
                        disabled={refreshingId === s.id}
                        className="p-2 rounded-lg hover:bg-white/5 text-white/50 hover:text-primary-light disabled:opacity-40"
                      >
                        <RefreshCw size={16} className={refreshingId === s.id ? 'animate-spin' : ''} />
                      </button>
                      <button
                        onClick={() => openEditForm(s)}
                        title="Editar"
                        className="p-2 rounded-lg hover:bg-white/5 text-white/50 hover:text-accent-light"
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(s.id)}
                        title="Excluir"
                        className="p-2 rounded-lg hover:bg-white/5 text-white/50 hover:text-red-400"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {servers.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-white/30">Nenhum servidor cadastrado</td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Terminal, Globe, Shield, Cable, Boxes,
  Users, UserCog, Server, CreditCard, ShoppingBag, BarChart3,
  Bell, Settings, LogOut
} from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'

const menuItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/ssh', label: 'SSH', icon: Terminal },
  { to: '/v2ray', label: 'V2Ray', icon: Globe },
  { to: '/wireguard', label: 'WireGuard', icon: Shield },
  { to: '/openvpn', label: 'OpenVPN', icon: Cable },
  { to: '/combo', label: 'Combo', icon: Boxes },
  { to: '/clientes', label: 'Clientes', icon: Users },
  { to: '/revendedores', label: 'Revendedores', icon: UserCog },
  { to: '/servidores', label: 'Servidores', icon: Server },
  { to: '/pagamentos', label: 'Pagamentos', icon: CreditCard },
  { to: '/loja', label: 'Loja', icon: ShoppingBag },
  { to: '/relatorios', label: 'Relatórios', icon: BarChart3 },
  { to: '/notificacoes', label: 'Notificações', icon: Bell },
  { to: '/sistema', label: 'Sistema', icon: Settings },
]

export default function Sidebar() {
  const { username, role, logout } = useAuth()

  return (
    <aside className="w-64 h-screen bg-surface border-r border-white/5 flex flex-col shrink-0">
      <div className="p-5 border-b border-white/5">
        <h1 className="text-xl font-bold bg-gradient-to-r from-primary-light to-accent-light bg-clip-text text-transparent">
          Open Panel
        </h1>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
        {menuItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-xl text-sm transition-colors ${
                isActive
                  ? 'bg-primary/20 text-primary-light border border-primary/30'
                  : 'text-white/60 hover:bg-white/5 hover:text-white'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-white/5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">{username}</p>
            <p className="text-xs text-white/40">{role}</p>
          </div>
          <button onClick={logout} className="text-white/40 hover:text-red-400 transition-colors">
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </aside>
  )
}

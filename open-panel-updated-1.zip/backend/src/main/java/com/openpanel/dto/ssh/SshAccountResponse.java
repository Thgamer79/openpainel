package com.openpanel.dto.ssh;

import com.openpanel.domain.enums.AccountStatus;

import java.time.LocalDate;

public record SshAccountResponse(
        Long id,
        Long serverId,
        String serverName,
        String username,
        String password,
        LocalDate expirationDate,
        Integer connectionLimit,
        Integer deviceLimit,
        AccountStatus status
) {
}
